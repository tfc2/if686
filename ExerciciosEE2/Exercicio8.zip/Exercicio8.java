import java.util.concurrent.locks.*;
import java.util.Random;

class Vetor {
	public int valor;
	public Vetor proximo;

	public Vetor (int valor){
		this.valor = valor;
	}
}

public class Exercicio8 {
	
	public static Vetor comeco;

	public Lock travas[] = new Lock[50];

	public Exercicio8() {
		this.comeco = new Vetor (0);
		Exercicio8.preencheVetor(this.comeco, 1);
		for(int i = 0; i < 50; i++){
			travas[i] = new ReentrantLock();
		}
	}

	public static void preencheVetor(Vetor vetor, int contador){
		// comeco ja esta setado
		if (contador < 50){
			vetor.proximo = new Vetor(contador);
			contador++;
			Exercicio8.preencheVetor(vetor.proximo, contador);
		}
	}

	public static void imprimeVetor(Vetor vetor, int contador){
		if (contador < 50){
			System.out.print(" " + vetor.valor);
			contador++;
			Exercicio8.preencheVetor(vetor.proximo, contador);
		}
	}

	public void ler(Vetor vetor, int index, int contador){
		if(contador < index){
			contador++;
			ler(vetor.proximo, index, contador);
		} else {
			travas[index].lock();
			try{
				System.out.println("Leu " + vetor.valor + " no índice " + contador + ".");	
			} finally{
				travas[index].unlock();
			}
		}
	}

	public void escrever(Vetor vetor, int index, int valor, int contador){
		if(contador < index){
			contador++;
			escrever(vetor.proximo, index, valor, contador);
		} else {
			travas[index].lock();
			try{
				vetor.valor = valor;
				System.out.println("Escreveu " + vetor.valor + " no índice " + contador + ".");	
			} finally{
				travas[index].unlock();
			}
		}
	}

	public void swap(Vetor vetor1, Vetor vetor2, int index1, int index2, int contador1, int contador2){
		
		if(contador1 < index1){
			contador1++;
			swap(vetor1.proximo, vetor1, index1, index2, contador1, contador2);
		}

		if(contador2 < index2){
			contador2++;
			swap(vetor2.proximo, vetor1, index1, index2, contador1, contador2);
		}

		if(contador1 == index1 && contador2 == index2){
			boolean t1 = travas[index1].tryLock();
			boolean t2 = travas[index2].tryLock();

			try {
				while (!(t1 && t2)){
					if (!t1){
						travas[index1].unlock();
					}
					if (!t2){
						travas[index2].unlock();
					}
					t1 = travas[index1].tryLock();
					t2 = travas[index2].tryLock();
				}

				int aux = vetor1.valor;
				vetor1.valor = vetor2.valor;
				vetor2.valor = aux;
				System.out.println("Trocou " + vetor2.valor + " no índice " + contador1 + " com " + vetor1.valor + " no índice " + contador2 + ".");	

			} finally{
				if (!t1){
					travas[index1].unlock();
				}
				if (!t2){
					travas[index2].unlock();
				}			
			}
		}

	}

	public static void main(String args[]){
		
		Exercicio8 programa = new Exercicio8();

		Thread threads[] = new Thread[50];

		MyThread t = new MyThread(programa);

		for(int i = 0; i < 50; i++){
			threads[i] = new Thread(t);
			threads[i].start();
		}

		for(int i = 0; i < 50; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e){
			}
		}

		System.out.print("Vetor:");
		Exercicio8.imprimeVetor(Exercicio8.comeco, 0);
		System.out.println(".");

	}
	
}

class MyThread implements Runnable {
	
	public Exercicio8 programa = new Exercicio8();

	public MyThread(Exercicio8 programa){
		this.programa = programa;
	}

	public void run(){

		Random gerador = new Random();

		for(int i = 0; i < 2; i++){

			int metodo = gerador.nextInt(3);

			if(metodo == 0){
				int indexLeitura = gerador.nextInt(50);
				programa.ler(programa.comeco, indexLeitura, 0);
			} else if (metodo == 1){
				int indexEscrita = gerador.nextInt(50);
				int valorEscrita = gerador.nextInt(100000);
				programa.escrever(programa.comeco, indexEscrita, valorEscrita, 0);
			} else if (metodo == 2) {
				int indexSwap1 = gerador.nextInt(50);
				int indexSwap2 = gerador.nextInt(50);
				while (indexSwap1 == indexSwap2){
					indexSwap1 = gerador.nextInt(50);
					indexSwap2 = gerador.nextInt(50);
				}
				programa.swap(programa.comeco, programa.comeco, indexSwap1, indexSwap2, 0, 0);
			}
		}

	}

}