import java.util.concurrent.locks.*;
import java.util.Random;

public class SyncChan{

	public int fila[];
	public Lock trava;
	public volatile boolean vazia;
	public Condition produtor;
	public Condition consumidor;

	public SyncChan(){
		fila = new int[1];
		vazia = true;
		trava = new ReentrantLock();
		produtor = trava.newCondition();
		consumidor = trava.newCondition();
	}

	public void push(int valor){
		trava.lock();
		while(!vazia){
			try{
				consumidor.await();
			} catch (InterruptedException e){

			}
		}
		this.vazia = false;
		produtor.signalAll();
		this.fila[0] = valor;
		System.out.println("Inseriu " + this.fila[0] + ".");
		peek();
		trava.unlock();
	}

	public void pop(){
		trava.lock();
		while(vazia){
			try{
				produtor.await();
			} catch (InterruptedException e){

			}
		}

		this.vazia = true;
		consumidor.signalAll();
		System.out.println("Removeu " + this.fila[0] + ".");
		this.fila[0] = -1;
		peek();
		trava.unlock();
	}

	public void peek(){
		if(this.fila[0] == -1){
			System.out.println("Fila vazia!");
		} else {
			System.out.println("Fila: " + this.fila[0] + ".");
		}
	}

	public static void main(String args[]){

		SyncChan f = new SyncChan();

		Thread threads[] = new Thread[50];

		Produtor p = new Produtor(f);

		Consumidor c = new Consumidor(f);

		for(int i = 0; i < 25; i++){
			threads[i] = new Thread(p);
		}

		for(int i = 25; i < 50; i++){
			threads[i] = new Thread(c);
		}

		for(int i = 0; i < 50; i++){
			threads[i].start();
		}

		for(int i = 0; i < 50; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e){

			}
		}

	}

}

class Produtor implements Runnable {

	SyncChan f;

	public Produtor(SyncChan f){
		this.f = f;
	}

	public void run(){

		Random gerador = new Random();

		for(int i = 0; i < 100; i++){

			int valor = gerador.nextInt(10000);

			f.push(valor);

			try{
				Thread.sleep(100);
			} catch (InterruptedException e){
			}
		}
	}


}

class Consumidor implements Runnable {

	SyncChan f;

	public Consumidor(SyncChan f){
		this.f = f;
	}

	public void run(){
		
		for(int i = 0; i < 100; i++){

			f.pop();

			try{
				Thread.sleep(100);
			} catch (InterruptedException e){
			}
		}
	}

}