package aula;

import java.util.ArrayList;

public class Exercicio1 implements Runnable {
	
	private long n1;
	private long n2;
	private static ArrayList<Long> primos = new ArrayList<Long>();
	
	public Exercicio1 (long n1, long n2){
		this.n1 = n1;
		this.n2 = n2;
	}
	

	public void run() {	
		
		for (long i = this.n1; i <= this.n2; i++){
			
	        long primo = 0;
	        for(long j = 2; j < i; j++){
	            if(i%j==0){
	                primo = 1;
	            }
	        }
	        
	        if(primo==0) {
	        	Exercicio1.primos.add(i);
	        }
		}
		
	}
	
	public static void main(String args[]) {
		
		long tStart = System.currentTimeMillis();
		
		long n = 100000;
		int x = 1000;
		
		Thread[] threads = new Thread[x]; 
		
		for (int i = 0; i < x; i ++){
			long n1 = ((i/x)*n) + 1;
			long n2 =  (((i+1)/x)*n);
			
			threads[i] = (new Thread(new Exercicio1(n1, n2)));
			
			threads[i].start();	
		}
		
		for (int i = 0; i < x; i ++){
			try {
				threads[i].join();	
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		/* Para imprimir os numeros
		for (int i = 0; i < primos.size(); i++){
			System.out.println(primos.get(i));
		}
		*/

		long tEnd = System.currentTimeMillis();
		long tTotal = tEnd - tStart;
			 
		System.out.println("Tempo total em ms: " + tTotal);		

	}
	
	
	/*
	 *    Tabela de exemplo: 
	 *    X           N=1      N=10     N=100    N=1000   N=10000  N=100000
	 *    10          0ms      0ms      0ms      15ms     1233ms   127735ms   
	 *    100         15ms     16ms     16ms     16ms     1232ms   127777ms 
	 *    1000        109ms    109ms    109ms    124ms    1341ms   127777ms 
	 *    
	 */

	
}
