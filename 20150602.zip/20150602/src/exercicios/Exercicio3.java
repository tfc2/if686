package exercicios;

// Com contadores locais
public class Exercicio3 implements Runnable {

	private int x;
	private int n;

	public Exercicio3 (int x, int n){
		this.x = x;
		this.n = n;
	}
	

	public void run() {	
		
		for (int i = 0; i <= this.x; i++){
			
			System.out.println("Thread: " + this.n + " Contador: " + i);
			
		}
		
	}
	
	public static void main(String args[]) {
		
		int n = 10;
		int x = 10;
		
		Thread[] threads = new Thread[n]; 
		
		for (int i = 0; i < n; i ++){
			
			threads[i] = (new Thread(new Exercicio3(x, (i+1))));
			
			threads[i].start();	
		}
		
		for (int i = 0; i < x; i ++){
			try {
				threads[i].join();	
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	

	}
	
	
}
