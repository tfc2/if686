package exercicios;

public class Exercicio1Parte2 implements Runnable {
		
	private long a;
	private long b;
	
	public Exercicio1Parte2 (long a, long b) {
		this.a = a;
		this.b = b;
	}
	
	
	public void run() {	
		for (long i = a; i <= b; i++){
		}
	}
	
	public static void main(String args[]) {
		
		long tStart = System.currentTimeMillis();
		
		 Thread t1 = (new Thread(new 

		Exercicio1Parte2(1, 200)));
		 
		 t1.start();
		 
		 try {
			t1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		 
		 Thread t2 = (new Thread(new 

		Exercicio1Parte2(201, 20000)));
		 
		 t2.start();
		 
		 try {
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		 Thread t3 = (new Thread(new 

		Exercicio1Parte2(20001, 2000000)));
		 
		 t3.start();
		 
		 try {
			t3.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		 Thread t4 = (new Thread(new 

		Exercicio1Parte2(2000001, 200000000)));
		 
		 t4.start();
		 
		 try {
			t4.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		 Thread t5 = (new Thread(new 

		Exercicio1Parte2(200000001, 2000000000)));
		 
		 t5.start();
		 
		 try {
			t5.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		 
		 long tEnd = System.currentTimeMillis();
		 long tTotal = tEnd - tStart;
		 
		System.out.println("Tempo total em ms: " + tTotal);
		 
	}

	
}
