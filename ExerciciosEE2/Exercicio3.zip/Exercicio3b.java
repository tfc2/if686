public class Exercicio3b  {

	public long contador;

	public Exercicio3b(){
		this.contador = 0;
	}

	public synchronized long incrementaContador(){
		this.contador++;
		return this.contador;
	}

	public static void main(String args[]){

		Exercicio3b programa = new Exercicio3b();
		Thread threads[] = new Thread[100];
		MyThread t = new MyThread(programa);

		for(int i = 0; i < 100; i++){
			threads[i] = new Thread(t);
			threads[i].start();
		}

		for(int i = 0; i < 100; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e){
			}
		}

	}

}

class MyThread implements Runnable{

	Exercicio3b programa;

	public MyThread(Exercicio3b programa){
		this.programa = programa;
	}

	public void run(){

		for(int i = 0; i < 200; i++){
			long numero = programa.incrementaContador();
			System.out.println(numero);
		}
	}

}
