import java.util.Vector;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicBoolean;

public class Exercicio5b {

	public Vector<Long> fila;
	public long contador;

	// AtomicBooleans para dizer se os metodos ja estao em uso
	public AtomicBoolean modificaFila;
	public AtomicBoolean incremento;

	public Exercicio5b(){
		this.fila = new Vector<Long>();
		this.contador = 0;
		this.modificaFila = new AtomicBoolean(false);
		this.incremento = new AtomicBoolean(false);
	}

	public void insere(int numero, long elemento){
		while(!this.modificaFila.compareAndSet(false, true)){
			// fica esperando a flag ser false para poder prosseguir
		}

		fila.add(elemento);
		System.out.print("Thread " + numero + " inseriu elemento " + elemento + ". Fila:");
		for (int i = 0; i < this.fila.size(); i++){
			System.out.print(" " + fila.get(i));
		}
		System.out.println(".");

		this.modificaFila.set(false);
	}

	public void remove(int numero){
		while(!this.modificaFila.compareAndSet(false, true)){
			// fica esperando a flag ser false para poder prosseguir
		}

		fila.remove(0);
		if(fila.size() == 0){
			System.out.print("Thread " + numero + " removeu o primeiro elemento. Fila vazia");
		} else {
			System.out.print("Thread " + numero + " removeu o primeiro elemento. Fila:");
			for (int i = 0; i < this.fila.size(); i++){
				System.out.print(" " + fila.get(i));
			}
		}
		System.out.println(".");

		this.modificaFila.set(false);
	}

	public long incrementaContador(){

		while(!this.incremento.compareAndSet(false, true)){
		
		}
		
		this.contador++;

		long aux = this.contador;
		
		this.incremento.set(false);

		return aux;
	}

	public static void main (String args[]){

		Scanner in = new Scanner(System.in);

		System.out.println("Digite um numero de threads: ");

		int n = in.nextInt();

		Exercicio5b programa = new Exercicio5b();

		Thread threads[] = new Thread[n];

		for(int i = 0; i < n; i++){
			threads[i] = new Thread(new MyThread2(programa, i));
			threads[i].start();
		}

		for(int i = 0; i < n; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e) {
			}
		}

	}


}

class MyThread2 implements Runnable {

	public Exercicio5b programa;
	public int numero;

	public MyThread2(Exercicio5b programa, int numero){
		this.programa = programa;
		this.numero = numero;
	}

	public void run(){
		for(int i = 0; i < 200; i++){

			// calculo do elemento a partir do contador			
			long elemento = this.programa.incrementaContador();
			
			// insercao
			this.programa.insere(this.numero, elemento);
			
			// delay para remocao
			try {
				Thread.sleep(100);
			} catch (InterruptedException e){

			}
			
			// remocao
			this.programa.remove(this.numero);
		}
	}

}