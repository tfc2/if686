package exercicios;

// Com contadores globais
public class Exercicio4 implements Runnable {

	private int x;
	private int n;
	private static int i; // variavel global

	public Exercicio4 (int x, int n){
		this.x = x;
		this.n = n;
	}
	

	public void run() {	
		
		for (int i = Exercicio4.i; i <= this.x; i++){
			
			System.out.println("Thread: " + n + " Contador: " + i);
			
			Exercicio4.i++;
			
		}
		
	}
	
	public static void main(String args[]) {
		
		Exercicio4.i = 0;
		
		int n = 10;
		int x = 1000;
		
		Thread[] threads = new Thread[n]; 
		
		for (int i = 0; i < n; i ++){
			
			threads[i] = (new Thread(new Exercicio4(x, (i+1))));
			
			threads[i].start();	
		}
		
		for (int i = 0; i < n; i ++){
			try {
				threads[i].join();	
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	

	}
	
	
}
