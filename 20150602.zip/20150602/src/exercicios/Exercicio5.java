package exercicios;

// Com contadores globais, sleep and interrupt
public class Exercicio5 implements Runnable {

	private int x;
	private static int n;
	private static int i; // variavel global
	private static Thread[] threads; 

	public Exercicio5 (int x, int n){
		this.x = x;
		Exercicio5.n = n;
	}
	

	public void run() {	
		
		for (int i = Exercicio5.i; i <= this.x; i++){
			
			System.out.println("Thread: " + n + " Contador: " + i);
			
			Exercicio5.i++;
		}
		
		/* chegou em x
		for (int i = 0; i < threads.length; i++){
			if(i != n){
				threads[i].interrupt();
			}
		}
		*/	
				
	}
	
	public static void main(String args[]) {
		
		Exercicio5.i = 0;
		
		int n = 10;
		int x = 100;
		
		threads = new Thread [n];
		
		for (int i = 0; i < n; i ++){
			
			threads[i] = (new Thread(new Exercicio5(x, (i+1))));
			
			threads[i].start();	
			
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}
		
		for (int i = 0; i < n; i ++){
			try {
				threads[i].join();	

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}


	}
	
	
}
