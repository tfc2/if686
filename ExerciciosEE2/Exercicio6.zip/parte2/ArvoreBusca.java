// parte2

import java.util.Random;

class Node {
	public Node esquerda;
	public Node direita;
	public int valor;

	public Node(int valor){
		this.valor = valor;
	}
}

public class ArvoreBusca {
	
	public static Node raiz;

	public void inserir(Node pai, Node filho){
		if(pai == null){
			raiz = filho;
		} else {
			if(filho.valor < pai.valor){
				if(pai.esquerda == null){
					synchronized (pai){
						pai.esquerda = filho;
						System.out.print(" " + filho.valor);
					}
				} else {
					inserir(pai.esquerda, filho);
				}
			} else if (filho.valor > pai.valor){
				if(pai.direita == null){
					pai.direita = filho;
					System.out.print(" " + filho.valor);
				} else {
					inserir(pai.direita, filho);
				}
			} else {
				System.out.print(" [tentou inserir " + filho.valor + ", mas já estava na árvore]");
			}
		}
	}

	public static void imprime(Node no){
		if(ArvoreBusca.raiz == null){
			System.out.println("está vazia!");
		} else {
			if(no != null){
				imprime(no.esquerda);
				System.out.print(" "+ no.valor);
				imprime(no.direita);
			}	
		}
	}

	public static void main(String args[]){
		
		long tStart = System.currentTimeMillis();

		ArvoreBusca arvore = new ArvoreBusca();

		/* Sequencial:
		for(int i = 0; i < 100000; i++){
			Random gerador = new Random();
			int valor = gerador.nextInt(100000);
			
			Node no = new Node(valor);
			arvore.inserir(arvore.raiz, no);
		} 
		
		*/

		Thread threads[] = new Thread[50];

		MyThread t = new MyThread(arvore);

		System.out.println();
		System.out.print("Elementos inseridos:");

		for(int i = 0; i < 50; i++){
			threads[i] = new Thread(t);
			threads[i].start();
		}

		for(int i = 0; i < 50; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e){
			}
		}

		System.out.println(".");
		System.out.println();
		System.out.print("Arvore ordenada:");
		imprime(ArvoreBusca.raiz);
		System.out.println(".");
		System.out.println();

		long tEnd = System.currentTimeMillis();
		long tTotal = tEnd - tStart;
		 
		System.out.println("Tempo total em ms: " + tTotal);

	}

}

class MyThread implements Runnable {

	ArvoreBusca arvore;

	public MyThread (ArvoreBusca arvore){
		this.arvore = arvore;
	}


	public void run(){
		Random gerador = new Random();

		for (int i = 0; i < 2000; i++){
			int valor = gerador.nextInt(100000);
			Node no = new Node(valor);
			arvore.inserir(arvore.raiz, no);
		}
	}

}


/*
 * Tempo sem threads: 509ms (sequencial inserindo 100000 nos, ou seja, 50 * 2000)
 * Tempo com threads: 727ms (50 threds cada uma inserindo 2000 nos)
*/


