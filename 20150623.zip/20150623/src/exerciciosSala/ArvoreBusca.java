package exerciciosSala;

class Node{
	long valor;
	Node esquerda;
	Node direita;
	
	public Node (long valor){
		this.valor = valor;
	}
}

public class ArvoreBusca {
	
	Node raiz;
	
	synchronized void inserir (Node pai, Node no){
		
		if (pai == null){
			pai = no;
		} else if (pai.valor > no.valor){
			inserir (pai.esquerda, no);
		} else if (pai.valor < no.valor){
			inserir (pai.direita, no);
		}
		// else = mesmo valor, fazer nada
		
	}
	
	// faltou fazer o run
	
	public static void main(String args[]) {
		
		long contador = 0000;
		
		Thread[] threads = new Thread[50]; 

		for (int i = 0; i < 50; i ++){
			
			Node no = new Node (contador);
			
			contador ++;
			
			threads[i] = (new Thread()); // falta finalizar
			
			threads[i].start();	
		}
		
		for (int i = 0; i < 50; i ++){
			try {
				threads[i].join();	
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	
		
	}

}