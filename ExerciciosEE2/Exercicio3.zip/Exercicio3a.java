public class Exercicio3a implements Runnable {

	public void run(){
		for (int i = 1; i <= 200; i++){
			System.out.println(i);
		}
	}

	public static void main(String args[]){

		Thread threads[] = new Thread[100];

		for (int i = 0; i < 100; i++){
			threads[i] = new Thread(new Exercicio3a());
			threads[i].start();
		}

		for (int i = 0; i < 100; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e){
			}
		}

	}

}
