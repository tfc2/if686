import java.util.concurrent.locks.*;
import java.util.Random;

class Elemento {
	public int valor;

	public Elemento (int valor){
		this.valor = valor;
	}
}

public class Exercicio8 {
	
	public static Elemento vetor[] = new Elemento[50];
	public Lock travas[] = new Lock[50];

	public Exercicio8() {
		for(int i = 0; i < 50; i++){
			vetor[i] = new Elemento(i);
		}

		for(int i = 0; i < 50; i++){
			travas[i] = new ReentrantLock();
		}
	}

	public static void imprimeVetor(){
		System.out.println();
		System.out.print("Vetor:");
		for(int i = 0; i < 50; i++){
			System.out.print(" " + Exercicio8.vetor[i].valor);
		}
		System.out.println(".");
	}

	public void ler(int i){
		travas[i].lock();
		try{
			System.out.println("Leu " + Exercicio8.vetor[i].valor + " no índice " + i + ".");	
		} finally{
			travas[i].unlock();
		}
	}

	public void escrever(int i, int valor){
		travas[i].lock();
		try{
			vetor[i].valor = valor;
			System.out.println("Escreveu " + Exercicio8.vetor[i].valor + " no índice " + i + ".");	
		} finally{
			travas[i].unlock();
		}
	}

	public void swap(int i1, int i2){

		boolean t1 = travas[i1].tryLock();
		boolean t2 = travas[i2].tryLock();

		try {
			while (!(t1 && t2)){
				if (t1){
					travas[i1].unlock();
				}
				if (t2){
					travas[i2].unlock();
				}
				t1 = travas[i1].tryLock();
				t2 = travas[i2].tryLock();
			}

			int aux = vetor[i1].valor;
			vetor[i1].valor = vetor[i2].valor;
			vetor[i2].valor = aux;
			System.out.println("Trocou " + vetor[i2].valor + " no índice " + i1 + " com " + vetor[i1].valor + " no índice " + i2 + ".");	

		} finally{
			if (t1){
				travas[i1].unlock();
			}
			if (t2){
				travas[i2].unlock();
			}			
		}

	}

	public static void main(String args[]){
		
		Exercicio8 programa = new Exercicio8();

		Thread threads[] = new Thread[50];

		MyThread t = new MyThread(programa);

		for(int i = 0; i < 50; i++){
			threads[i] = new Thread(t);
			threads[i].start();
		}

		for(int i = 0; i < 50; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e){
			}
		}

		Exercicio8.imprimeVetor();

	}
	
}

class MyThread implements Runnable {
	
	public Exercicio8 programa = new Exercicio8();

	public MyThread(Exercicio8 programa){
		this.programa = programa;
	}

	public void run(){

		Random gerador = new Random();

		for(int i = 0; i < 200; i++){

			int metodo = gerador.nextInt(3);

			if(metodo == 0){
				int indexLeitura = gerador.nextInt(50);
				programa.ler(indexLeitura);
			} else if (metodo == 1){
				int indexEscrita = gerador.nextInt(50);
				int valorEscrita = gerador.nextInt(100000);
				programa.escrever(indexEscrita, valorEscrita);
			} else if (metodo == 2) {
				int i1 = gerador.nextInt(50);
				int i2 = gerador.nextInt(50);
				while (i1 == i2){
					i1 = gerador.nextInt(50);
					i2 = gerador.nextInt(50);
				}
				programa.swap(i1, i2);
			}
		}

	}

}