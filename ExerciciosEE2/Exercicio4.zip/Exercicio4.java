public class Exercicio4  {

	public long contador;
	public static Thread threads[] = new Thread[100];

	public Exercicio4(){
		this.contador = 0;
	}

	public synchronized long incrementaContador(){
		this.contador++;
		return this.contador;
	}

	public static void main(String args[]){

		Exercicio4 programa = new Exercicio4();

		for(int i = 0; i < 100; i++){
			threads[i] = new Thread(new MyThread(programa, i));
			threads[i].start();
		}

		for(int i = 0; i < 100; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e){
			}
		}

	}

}

class MyThread implements Runnable{

	Exercicio4 programa;
	int flagThread;

	public MyThread(Exercicio4 programa, int flagThread){
		this.programa = programa;
		this.flagThread = flagThread;
	}

	public void run(){

		for(int i = 0; i < 200; i++){
			long numero = programa.incrementaContador();
			System.out.println(numero);
			try {
				Thread.sleep(1); 
			} catch (InterruptedException e) {
				return;
			}
		}

		for(int i = 0; i < 100; i++){
			if(i != flagThread){
				programa.threads[i].interrupt();
			}
		}	
	}

}
