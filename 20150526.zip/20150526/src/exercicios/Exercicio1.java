package exercicios;

public class Exercicio1 implements Runnable {
		
	private long a;
	private long b;
	
	public Exercicio1 (long a, long b) {
		this.a = a;
		this.b = b;
	}
	
	
	public void run() {	
		for (long i = a; i <= b; i++){
			System.out.println(i);
		}
	}
	
	public static void main(String args[]) {
		
		 Thread t1 = (new Thread(new 

		Exercicio1(1, 200)));
		 
		 t1.start();
		 
		 try {
			t1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		 
		 Thread t2 = (new Thread(new 

		Exercicio1(201, 20000)));
		 
		 t2.start();
		 
		 try {
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		 Thread t3 = (new Thread(new 

		Exercicio1(20001, 2000000)));
		 
		 t3.start();
		 
		 try {
			t3.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		 Thread t4 = (new Thread(new 

		Exercicio1(2000001, 200000000)));
		 
		 t4.start();
		 
		 try {
			t4.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		 Thread t5 = (new Thread(new 

		Exercicio1(200000001, 2000000000)));
		 
		 t5.start();
		 
		 try {
			t5.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		 
	}

	
}
