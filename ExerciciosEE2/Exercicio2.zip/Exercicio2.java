public class Exercicio2 {

	public long contador;

	public Exercicio2(){
		this.contador = 0;
	}

	public synchronized long incrementaContador(){
		this.contador++;
		return this.contador;
	}

	public static void main (String args[]){

		Exercicio2 programa = new Exercicio2();

		// alterar aqui o numero de threads, junto com os dois contadores abaixo
		Thread threads[] = new Thread[100];

		MyThread t = new MyThread(programa);

		for(int i = 0; i < 100; i++){
			threads[i] = new Thread(t);
			threads[i].start();
		}

		for(int i = 0; i < 100; i++){
			try{
				threads[i].join();
			} catch (InterruptedException e){
			}
		}

	}


}

class MyThread implements Runnable {

	public Exercicio2 programa;

	public MyThread(Exercicio2 programa){
		this.programa = programa;
	}

	public void run(){

		// alterar aqui a quantidade de n de numeros (* 100 threads)
		for (int i = 0; i < 200; i++){

			long numero = programa.incrementaContador();

			long primo = 0;
		    for(long j = 2; j < numero; j++){
		        if(numero%j==0){
		            primo = 1;
		        }
		    }

		    if(primo == 0){
		    	System.out.println(numero);
		    }
		}

	}

}

