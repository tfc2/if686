package exerciciosSala;

import java.util.Random;

class Node {
	long valor;
	Node esquerda;
	Node direita;
	
	public Node (long valor){
		this.valor = valor;
		this.esquerda = null;
		this.direita = null;
	}
}

public class ArvoreBusca {
	
	Node raiz;
	
	synchronized void inserir (Node pai, Node no){
		if (raiz == null){
			raiz = no;
		}else if (pai.valor > no.valor){
			if (pai.esquerda == null){
				pai.esquerda = no;
			} else {
				inserir (pai.esquerda, no);
			}
		} else if (pai.valor < no.valor){
			if (pai.direita == null){
				pai.direita = no;
			} else {
				inserir (pai.direita, no);
			}
		}
		// else = mesmo valor, fazer nada
		
	}
	
	static void imprimir (Node no){
		if (no != null){
			
			System.out.println(no.valor);
			
			if (no.esquerda != null){
				imprimir(no.esquerda);
			}
			if (no.direita != null){
				imprimir(no.direita);
			}
			
		}
		
	}
	

	public static void main(String args[]) {
		
		long tStart = System.currentTimeMillis();
		
		ArvoreBusca arvore = new ArvoreBusca();			
		
		/*
		for(int i = 0; i < 100000; i++){
			Random gerador = new Random();
			int valor = gerador.nextInt();
			
			Node no = new Node(valor);
			
			if (arvore.raiz == null){
				arvore.raiz = no;
			} else {
				arvore.inserir(arvore.raiz, no);
			}
		} */
		
		Thread[] threads = new Thread[50]; 
								
		MyThread t = new MyThread(arvore);
		
		for (int i = 0; i < 50; i ++){
																	
			threads[i] = (new Thread(t)); 
	
			threads[i].start();	

		}
		
		imprimir(arvore.raiz);
		
	    long tEnd = System.currentTimeMillis();
		long tTotal = tEnd - tStart;
		 
		//System.out.println("Tempo total em ms: " + tTotal);

	}

}

class MyThread implements Runnable{
	
	ArvoreBusca arvore;
	
	MyThread (ArvoreBusca arvore){
		this.arvore = arvore;
	}

	public void run(){
		for(int i = 0; i < 2000; i++){
			Random gerador = new Random();
			int valor = gerador.nextInt();
			
			Node no = new Node(valor);
			
			if (arvore.raiz == null){
				arvore.raiz = no;
			} else {
				arvore.inserir(arvore.raiz, no);
			}
		}
	}
		
}

/*
 * Tempo sem threads: 73ms (sequencial inserindo 100000 nos, ou seja, 50 * 2000)
 * Tempo com threads: 16ms (50 threds cada uma inserindo 2000 nos)
 * */
